# AI IT Helpdesk Ticket Assistant

A local-first Streamlit prototype for structured incident intake, support-article retrieval, duplicate checks, explainable priority and routing, and reviewed JSON ticket preparation.

## Run on Windows

1. Install Python 3.10 or newer. Python 3.10+ is supported; the app uses Python 3.10 type syntax.
2. Open PowerShell in this project folder.
3. Create and activate a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Open `.env` and replace `OPENAI_API_KEY=replace_me` with a newly issued key. The provided TCS-compatible endpoint and model are already configured. Do not commit `.env`.
6. Start the app:

   ```powershell
   streamlit run app.py
   ```

The app remains usable without a configured LLM key: deterministic intake, local article retrieval, duplicate matching, priority rules, and routing continue to work. LLM failures are surfaced in the chat and audit log. Do not use a key that has been pasted into chat or an image; rotate exposed credentials before use.

### Tested dependency compatibility

The dependency ranges in `requirements.txt` intentionally include older compatible releases and cap unsupported major versions:

| Package | Supported range | Versions tested here |
| --- | --- | --- |
| Streamlit | `>=1.49.1,<2` | 1.49.1 and 1.66.0 |
| OpenAI Python SDK | `>=1.50.2,<3` | 1.50.2 and 2.54.0 |
| python-dotenv | `>=1.0.1,<2` | 1.0.1 and 1.2.4 |

The test suite and Streamlit render check pass on both the minimum versions and the installed newer versions. This is a tested compatibility range, not a promise to run on every historical or future library version: older releases are excluded because the app relies on newer Streamlit chat/UI APIs, and a future major release must be tested before removing its upper bound. Use a current supported Python release and install dependencies from `requirements.txt`.

## Sample data and uploads

`data/` contains sample assets, tickets, known outages, service categories, priority rules, resolver mappings, and approved support articles. The sidebar accepts:

- CSV: service categories, resolver-group mappings, ticket examples, assets, and known outages.
- JSON: priority matrix.
- TXT or Markdown: support articles. Use `ID:`, `Title:`, `Approved: yes`, and `Steps:` fields; separate articles with a line containing `---`. Articles without explicit approval are not recommended.

Uploads replace the corresponding sample table for the current Streamlit session; uploaded articles are added to the local article set. For persistent customization, edit the corresponding file under `data/`. Required CSV columns are validated in the app. Asset lookup is available in the sidebar by asset ID.

## Workflow and safety

The app opens with a short workflow guide and intake progress. Each input also has a help tip (`?`) explaining how the value is used. The sidebar's **Active data and CSV templates** section shows loaded record counts and provides header-only CSV templates for preparing uploads.

- **Issue Intake Agent** extracts fields from free text, remembers answers in Streamlit session state, and asks once for missing device, application, location, impact, urgency, and attempted fixes.
- **Knowledge Retrieval Agent** searches local articles and returns only approved sample guidance with source IDs and filenames.
- **Ticket Routing Agent** compares recent tickets and outages, applies the uploaded impact/urgency matrix, and maps the category to its resolver group.
- **Human review** is required before a ticket is marked ready. The app prepares and downloads JSON; it does not create a real ticket or call an external ticketing system.
- Feedback changes article ranking for the current session. Events, LLM fallback notices, ticket preparation, feedback, and review are kept in a downloadable session audit log.
- **Guided intake** includes selectable starters for common VPN, email, Teams, sign-in/MFA, device, printer, business application, and phishing issues. Optional device, application, location, impact, urgency, and attempted-fix fields are passed into the same conversational workflow.
- **Ticket tagging** offers two separate dropdowns: ticket type (`Incident`, `Service Request`, `Access Request`, `Security Incident`, or `Problem / Outage`) and affected service/category. Both selections are included in the reviewed ticket JSON, and free-text intake can suggest a ticket type.
- **Quick tools** in the sidebar let staff search approved guidance, preview a priority from the configured matrix, and check issue text against recent tickets/outages before completing intake.
- **Asset prefill** can copy a selected asset's device, application, location, and ID into guided intake. Review these details before submitting.
- **Session reset** clears the current conversation, collected ticket details, article feedback, and audit log; it does not change files under `data/`.

Priority uses an explicit rule table; missing impact or urgency is treated as Medium and disclosed in the explanation. Classifications with low confidence, possible duplicates, or missing mappings are flagged for human review.

## Test

Run the focused tests with:

```powershell
python -m unittest discover -s tests -v
```

## Ticket JSON

The editable review JSON includes `ticket_type`, `category`, `summary`, `diagnostics`, `evidence`, `recommended_self_service`, `priority`, `suggested_resolver_group`, classification confidence, duplicate matches, and human-review status.
