from __future__ import annotations

import csv
import io
import json
import os
import re
from datetime import date, datetime, timedelta
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any
from uuid import uuid4

import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI, OpenAIError


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
REQUIRED_INTAKE_FIELDS = (
    "device",
    "application",
    "location",
    "impact",
    "urgency",
    "attempted_fixes",
)
TICKET_TYPES = (
    "Incident",
    "Service Request",
    "Access Request",
    "Security Incident",
    "Problem / Outage",
)
UNKNOWN_VALUES = {"", "unknown", "not sure", "n/a", "na", "none", "not provided"}
STOP_WORDS = {
    "about", "after", "again", "also", "and", "are", "because", "been", "being",
    "but", "can", "could", "did", "does", "for", "from", "have", "help", "into",
    "issue", "its", "just", "maybe", "need", "not", "our", "please", "problem",
    "that", "the", "then", "this", "was", "with", "would", "you",
}


def read_csv_file(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def parse_csv_upload(upload: Any) -> list[dict[str, str]]:
    text = upload.getvalue().decode("utf-8-sig")
    return list(csv.DictReader(io.StringIO(text)))


def csv_template_bytes(path: Path) -> bytes:
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        headers = next(csv.reader(file), [])
    output = io.StringIO(newline="")
    csv.writer(output, lineterminator="\n").writerow(headers)
    return output.getvalue().encode("utf-8")


def load_uploaded_csv(key: str, filename: str) -> list[dict[str, str]]:
    uploaded = st.session_state.get(key)
    return parse_csv_upload(uploaded) if uploaded is not None else read_csv_file(DATA_DIR / filename)


def parse_articles(text: str, source_name: str) -> list[dict[str, str]]:
    articles: list[dict[str, str]] = []
    for block in re.split(r"(?m)^\s*---\s*$", text):
        block = block.strip()
        if not block:
            continue
        match = re.search(r"(?m)^ID:\s*(.+)$", block)
        title_match = re.search(r"(?m)^Title:\s*(.+)$", block)
        approved_match = re.search(r"(?im)^Approved:\s*(.+)$", block)
        article_id = match.group(1).strip() if match else source_name
        title = title_match.group(1).strip() if title_match else article_id
        approved = approved_match.group(1).strip().casefold() if approved_match else "no"
        articles.append({
            "id": article_id,
            "title": title,
            "content": block,
            "source": source_name,
            "approved": approved,
        })
    return articles


def load_articles() -> list[dict[str, str]]:
    articles = parse_articles(
        (DATA_DIR / "support_articles.txt").read_text(encoding="utf-8"),
        "support_articles.txt",
    )
    for upload in st.session_state.get("article_uploads", []):
        articles.extend(parse_articles(upload.getvalue().decode("utf-8-sig"), upload.name))
    return articles


def tokenize(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-z0-9][a-z0-9._-]*", text.casefold())
        if token not in STOP_WORDS and len(token) > 1
    }


def retrieve_articles(
    query: str,
    articles: list[dict[str, str]],
    feedback: dict[str, int] | None = None,
    limit: int = 3,
) -> list[dict[str, Any]]:
    query_terms = tokenize(query)
    if not query_terms:
        return []
    feedback = feedback or {}
    ranked: list[dict[str, Any]] = []
    for article in articles:
        if article.get("approved", "no").casefold() not in {"yes", "true", "approved"}:
            continue
        article_terms = tokenize(f"{article['title']} {article['content']}")
        overlap = len(query_terms & article_terms)
        score = overlap / max(len(query_terms), 1)
        score += feedback.get(article["id"], 0) * 0.04
        if score > 0:
            ranked.append({**article, "score": round(score, 3)})
    return sorted(ranked, key=lambda item: item["score"], reverse=True)[:limit]


def calculate_priority(
    impact: str,
    urgency: str,
    rules: list[dict[str, str]],
) -> tuple[str, str]:
    normalized_impact = impact.strip().title()
    normalized_urgency = urgency.strip().title()
    if normalized_impact.casefold() in UNKNOWN_VALUES:
        normalized_impact = "Medium"
    if normalized_urgency.casefold() in UNKNOWN_VALUES:
        normalized_urgency = "Medium"

    for rule in rules:
        if (
            rule["impact"].strip().casefold() == normalized_impact.casefold()
            and rule["urgency"].strip().casefold() == normalized_urgency.casefold()
        ):
            priority = rule["priority"].strip().upper()
            reason = (
                f"{normalized_impact} impact and {normalized_urgency} urgency "
                f"map to {priority} priority."
            )
            if impact.strip().casefold() in UNKNOWN_VALUES or urgency.strip().casefold() in UNKNOWN_VALUES:
                reason += " A missing value was conservatively treated as Medium."
            return priority, reason
    raise ValueError(f"No priority rule for impact={normalized_impact}, urgency={normalized_urgency}.")


def classify_category(
    description: str,
    categories: list[dict[str, str]],
) -> tuple[str, float]:
    text = description.casefold()
    best_category = "Other / Unclassified"
    best_score = 0
    for item in categories:
        keywords = [word.strip().casefold() for word in item.get("keywords", "").split("|") if word.strip()]
        score = sum(1 for keyword in keywords if keyword in text)
        if score > best_score:
            best_category = item["category"]
            best_score = score
    confidence = min(0.95, 0.45 + 0.12 * best_score) if best_score else 0.35
    return best_category, confidence


def classify_ticket_type(description: str) -> str:
    text = description.casefold()
    if any(term in text for term in ("phishing", "malware", "suspicious email", "security incident")):
        return "Security Incident"
    if any(term in text for term in ("outage", "service down", "widespread", "multiple teams")):
        return "Problem / Outage"
    if any(term in text for term in (
        "request access", "access request", "permission to", "new account", "grant access", "provision access",
    )):
        return "Access Request"
    if any(term in text for term in ("request a", "please provide", "new equipment", "order a", "install software")):
        return "Service Request"
    return "Incident"


def find_duplicates(
    description: str,
    tickets: list[dict[str, str]],
    outages: list[dict[str, str]],
    threshold: float = 0.42,
) -> list[dict[str, str | float]]:
    normalized = " ".join(sorted(tokenize(description)))
    if not normalized:
        return []
    matches: list[dict[str, str | float]] = []
    cutoff = date.today() - timedelta(days=30)
    for item, kind in [*((ticket, "ticket") for ticket in tickets), *((outage, "outage") for outage in outages)]:
        item_date = item.get("created_at") or item.get("start_date", "")
        try:
            parsed_date = datetime.strptime(item_date[:10], "%Y-%m-%d").date()
        except ValueError:
            continue
        if parsed_date < cutoff:
            continue
        comparison = " ".join(sorted(tokenize(f"{item.get('summary', '')} {item.get('description', '')}")))
        score = SequenceMatcher(None, normalized, comparison).ratio()
        if score >= threshold:
            matches.append({
                "type": kind,
                "id": item.get("ticket_id") or item.get("outage_id", "Unknown"),
                "summary": item.get("summary", ""),
                "status": item.get("status", "Known outage"),
                "similarity": round(score, 2),
            })
    return sorted(matches, key=lambda item: float(item["similarity"]), reverse=True)[:5]


def find_asset(asset_id: str, assets: list[dict[str, str]]) -> dict[str, str] | None:
    requested = asset_id.strip().casefold()
    if not requested:
        return None
    return next(
        (asset for asset in assets if asset.get("asset_id", "").strip().casefold() == requested),
        None,
    )


def validate_ticket(ticket: dict[str, Any]) -> None:
    if not isinstance(ticket, dict):
        raise ValueError("Ticket JSON must be an object.")
    required = {
        "ticket_id",
        "ticket_type",
        "category",
        "summary",
        "diagnostics",
        "evidence",
        "priority",
        "suggested_resolver_group",
    }
    missing = required - ticket.keys()
    if missing:
        raise ValueError(f"Ticket is missing required fields: {', '.join(sorted(missing))}.")
    if not isinstance(ticket["diagnostics"], dict) or not isinstance(ticket["evidence"], list):
        raise ValueError("Diagnostics must be an object and evidence must be a list.")
    if not isinstance(ticket["priority"], dict) or not {
        "level", "impact", "urgency", "explanation",
    }.issubset(ticket["priority"]):
        raise ValueError("Priority must include level, impact, urgency, and explanation.")
    if any(
        not isinstance(ticket[field], str) or not ticket[field].strip()
        for field in ("ticket_id", "ticket_type", "category", "summary", "suggested_resolver_group")
    ):
        raise ValueError("Ticket ID, category, summary, and resolver group must be non-empty strings.")
    if ticket["ticket_type"] not in TICKET_TYPES:
        raise ValueError(f"Ticket type must be one of: {', '.join(TICKET_TYPES)}.")


def extract_local_fields(text: str) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for field in ("impact", "urgency"):
        match = re.search(rf"\b{field}\s*(?:is|:|=)?\s*(high|medium|low)\b", text, re.I)
        if match:
            values[field] = match.group(1).title()
    device_match = re.search(r"\bdevice\s*(?:is|:|=)\s*([^,.;\n]+)", text, re.I)
    if device_match:
        values["device"] = device_match.group(1).strip()
    elif re.search(r"\b(laptop|desktop|computer|phone|mobile|printer|monitor|tablet)\b", text, re.I):
        match = re.search(r"\b(laptop|desktop|computer|phone|mobile|printer|monitor|tablet)\b", text, re.I)
        values["device"] = match.group(1).title()
    category_match = re.search(r"(?im)^category\s*(?:is|:|=)\s*([^\n]+)", text)
    if category_match:
        values["category"] = category_match.group(1).strip()
    type_match = re.search(r"(?im)^ticket\s*type\s*(?:is|:|=)\s*([^\n]+)", text)
    if type_match:
        candidate = type_match.group(1).strip()
        if candidate in TICKET_TYPES:
            values["ticket_type"] = candidate
    for field in ("application", "location"):
        match = re.search(rf"\b{field}\s*(?:is|:|=)\s*([^,.;\n]+)", text, re.I)
        if match:
            values[field] = match.group(1).strip()
    fix_match = re.search(r"(?:tried|attempted|already did)\s*(?::|=)?\s*([^.;\n]+)", text, re.I)
    if fix_match:
        values["attempted_fixes"] = fix_match.group(1).strip()
    if re.search(r"\b(no fixes|nothing tried|none attempted)\b", text, re.I):
        values["attempted_fixes"] = "None"
    asset_match = re.search(r"\b(?:asset|device)\s*(?:id|tag)?\s*[:#=]?\s*(AST-[A-Z0-9-]+)\b", text, re.I)
    if asset_match:
        values["asset_id"] = asset_match.group(1).upper()
    return values


def call_intake_llm(
    latest_message: str,
    known_fields: dict[str, Any],
    categories: list[dict[str, str]],
) -> tuple[dict[str, Any] | None, str | None]:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key or api_key in {"replace_me", "your_api_key_here"}:
        return None, "LLM is not configured; deterministic intake and local knowledge retrieval remain available."
    model = os.getenv("OPENAI_MODEL", "genailab-maas-gpt-5.3-codex")
    allowed_categories = [item["category"] for item in categories]
    prompt = f"""Extract helpdesk incident fields from the newest user message, using existing values only as context.
Return one JSON object with keys summary, category, ticket_type, device, application, location, impact, urgency,
attempted_fixes, diagnostics, confidence. Do not invent facts. Use null for unknown fields.
impact and urgency must be High, Medium, or Low when stated. category must be one of the allowed
categories when possible, otherwise Other / Unclassified. diagnostics must be a short string.
Allowed categories: {json.dumps(allowed_categories)}
Known values: {json.dumps(known_fields)}
Newest message: {latest_message}"""
    try:
        client = OpenAI(
            api_key=api_key,
            base_url=os.getenv("OPENAI_API_BASE", "https://genailab.tcs.in"),
            timeout=20.0,
        )
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a careful IT service desk intake assistant. Return valid JSON only."},
                {"role": "user", "content": prompt},
            ],
        )
    except OpenAIError as error:
        return None, f"LLM request failed ({type(error).__name__}); local intake will be used."
    try:
        content = response.choices[0].message.content or ""
    except (AttributeError, IndexError):
        return None, "LLM returned an unexpected response; local intake will be used."
    try:
        result = json.loads(content)
    except json.JSONDecodeError:
        return None, "LLM returned invalid JSON; local intake will be used."
    if not isinstance(result, dict):
        return None, "LLM returned an unexpected response; local intake will be used."
    return result, None


def group_for_category(
    category: str,
    resolver_groups: list[dict[str, str]],
) -> tuple[str, str]:
    for mapping in resolver_groups:
        if mapping["category"].strip().casefold() == category.strip().casefold():
            return mapping["resolver_group"], mapping.get("reason", "Mapped from the issue category.")
    return "Service Desk - Triage", "No category-specific mapping was found; sent to the triage queue."


def add_audit_event(event: str, details: dict[str, Any]) -> None:
    st.session_state.audit_log.append({
        "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
        "event": event,
        "details": details,
    })


def validate_priority_rules(rules: Any) -> None:
    levels = {"high", "medium", "low"}
    if not isinstance(rules, list):
        raise ValueError("Priority rules must be a JSON array.")
    combinations: set[tuple[str, str]] = set()
    for rule in rules:
        if not isinstance(rule, dict) or not {"impact", "urgency", "priority"}.issubset(rule):
            raise ValueError("Each priority rule needs impact, urgency, and priority fields.")
        impact = str(rule["impact"]).strip().casefold()
        urgency = str(rule["urgency"]).strip().casefold()
        if impact not in levels or urgency not in levels or not str(rule["priority"]).strip():
            raise ValueError("Priority rules must use High/Medium/Low impact and urgency and a non-empty priority.")
        combinations.add((impact, urgency))
    expected = {(impact, urgency) for impact in levels for urgency in levels}
    if combinations != expected:
        raise ValueError("Priority rules must define all nine High/Medium/Low impact and urgency combinations.")


def main() -> None:
    load_dotenv(ROOT / ".env")
    st.set_page_config(page_title="AI IT Helpdesk Assistant", page_icon="🛠️", layout="wide")
    st.title("AI IT Helpdesk Ticket Assistant")
    st.caption("Local-first incident intake, cited support guidance, duplicate detection, and explainable routing.")

    st.session_state.setdefault("messages", [])
    st.session_state.setdefault("intake", {})
    st.session_state.setdefault("asked_fields", set())
    st.session_state.setdefault("feedback", {})
    st.session_state.setdefault("audit_log", [])
    st.session_state.setdefault("prepared_ticket", None)

    st.info(
        "**Start here:** choose a common issue starter, describe what happened, and submit. "
        "The assistant will ask for missing details, search approved guidance, check for duplicates, "
        "and prepare a ticket for your review."
    )
    if st.session_state.prepared_ticket:
        st.progress(1.0, text="Ticket prepared — review routing, evidence, and JSON below")
    elif st.session_state.intake:
        completed_fields = sum(
            bool(st.session_state.intake.get(field))
            for field in REQUIRED_INTAKE_FIELDS
        )
        progress = completed_fields / len(REQUIRED_INTAKE_FIELDS)
        st.progress(progress, text=f"Intake details captured: {completed_fields} of {len(REQUIRED_INTAKE_FIELDS)}")
    else:
        st.progress(0.0, text="Intake not started")

    with st.expander("What each option does — quick navigation guide"):
        guide_left, guide_right = st.columns(2)
        with guide_left:
            st.markdown(
                "**Guided intake**\n"
                "- **Common issue:** loads a suggested starting description; edit it to match the real issue.\n"
                "- **Ticket type tag:** identifies an incident, request, access request, security case, or wider outage.\n"
                "- **Affected service tag:** steers classification and resolver-group routing.\n"
                "- **Device, application, location:** add context; asset lookup can fill these from the CSV.\n"
                "- **Impact and urgency:** feed the configured priority matrix.\n"
                "- **Attempted fixes:** prevents repeated suggestions and helps the resolver diagnose the issue.\n\n"
                "**Conversation**\n"
                "- Use chat when you prefer a free-text description or need to answer follow-up questions.\n"
                "- Session memory keeps known answers during this browser session."
            )
        with guide_right:
            st.markdown(
                "**Sidebar: support data**\n"
                "- Upload CSV/JSON/articles to replace or extend data for this session only.\n"
                "- Use the templates below to get the expected CSV headers.\n"
                "- Counts show which sample or uploaded data is currently active.\n\n"
                "**Sidebar: quick tools**\n"
                "- **Guidance search:** find approved article references before opening a ticket.\n"
                "- **Priority preview:** test the impact/urgency matrix without creating a ticket.\n"
                "- **Duplicate check:** compare text with recent ticket and outage examples.\n"
                "- **Asset lookup:** find a device record and optionally fill guided intake.\n\n"
                "**Ticket review**\n"
                "- Read the suggested steps, duplicate matches, priority and routing explanation.\n"
                "- Edit the JSON, confirm review, then download it or mark it ready locally.\n"
                "- The app does not submit a ticket to an external ITSM system."
            )

    with st.sidebar:
        st.header("Support data")
        st.caption("Uploads replace sample rows for this browser session only. Edit files under `data/` for persistent changes.")
        category_upload = st.file_uploader("Service categories CSV", type=["csv"], key="category_file", help="Categories and pipe-separated keywords used to classify issue descriptions.")
        priority_upload = st.file_uploader("Priority rules JSON", type=["json"], key="priority_file", help="Complete High/Medium/Low impact and urgency matrix.")
        resolver_upload = st.file_uploader("Resolver-group mappings CSV", type=["csv"], key="resolver_file", help="Maps each service category to its resolver team and routing explanation.")
        ticket_upload = st.file_uploader("Ticket examples CSV", type=["csv"], key="ticket_file", help="Recent tickets used only for duplicate-similarity checks.")
        asset_upload = st.file_uploader("Assets CSV", type=["csv"], key="asset_file", help="Asset ID, device, location and ownership information for asset lookup.")
        outage_upload = st.file_uploader("Known outages CSV (optional)", type=["csv"], key="outage_file", help="Known outages are included in duplicate checks.")
        article_uploads = st.file_uploader(
            "Support articles TXT/MD (one or more)",
            type=["txt", "md"],
            accept_multiple_files=True,
            key="article_files",
            help="Articles without `Approved: yes` are ignored by the self-service recommender.",
        )
        for state_key, uploaded in (
            ("category_data", category_upload),
            ("priority_data", priority_upload),
            ("resolver_data", resolver_upload),
            ("ticket_data", ticket_upload),
            ("asset_data", asset_upload),
            ("outage_data", outage_upload),
        ):
            if uploaded is not None:
                st.session_state[state_key] = uploaded
        st.session_state.article_uploads = article_uploads or []
        st.divider()
        if st.button("Reset current ticket and session memory", help="Clears the conversation, collected details, feedback and audit log."):
            for key in ("messages", "intake", "asked_fields", "feedback", "audit_log", "prepared_ticket"):
                st.session_state[key] = [] if key in {"messages", "audit_log"} else (
                    {} if key in {"intake", "feedback"} else None if key == "prepared_ticket" else set()
                )
            for key in (
                "guided_starter", "guided_ticket_type", "guided_category", "guided_description",
                "guided_device", "guided_application", "guided_location", "guided_fixes",
                "guided_asset_id", "guided_other_device", "guided_impact", "guided_urgency",
            ):
                st.session_state.pop(key, None)
            st.session_state.pop("_last_guided_starter", None)
            st.rerun()
        with st.expander("Asset lookup", expanded=True):
            st.caption("Find an assigned device. Use its record to prefill the guided intake fields.")
            asset_id = st.text_input("Search asset ID", placeholder="AST-1001", help="Try one of the sample IDs or your uploaded asset identifiers.")
        asset_to_apply = None

    try:
        categories = load_uploaded_csv("category_data", "service_categories.csv")
        priority_payload = st.session_state.get("priority_data")
        priority_rules = (
            json.loads(priority_payload.getvalue().decode("utf-8-sig"))
            if priority_payload is not None
            else json.loads((DATA_DIR / "priority_rules.json").read_text(encoding="utf-8"))
        )
        resolver_groups = load_uploaded_csv("resolver_data", "resolver_groups.csv")
        tickets = load_uploaded_csv("ticket_data", "ticket_examples.csv")
        assets = load_uploaded_csv("asset_data", "assets.csv")
        outages = load_uploaded_csv("outage_data", "known_outages.csv")
        articles = load_articles()
        validate_priority_rules(priority_rules)
    except (OSError, UnicodeDecodeError, csv.Error, json.JSONDecodeError, AttributeError, ValueError) as error:
        st.error(f"Could not load a support dataset: {error}")
        st.stop()

    if asset_id:
        asset = find_asset(asset_id, assets)
        if asset:
            st.sidebar.success("Asset record found.")
            st.sidebar.json(asset)
            if st.sidebar.button("Use this asset in guided intake", help="Prefills device, application, location, and asset ID; review them before submitting."):
                asset_to_apply = asset
        else:
            st.sidebar.info("No matching asset ID in the loaded asset CSV.")

    required_columns = {
        "category_data": {"category", "keywords"},
        "resolver_data": {"category", "resolver_group"},
        "ticket_data": {"ticket_id", "summary", "created_at"},
        "asset_data": {"asset_id", "device", "location"},
        "outage_data": {"outage_id", "start_date", "summary", "description", "status"},
    }
    loaded_sets = {
        "category_data": categories,
        "resolver_data": resolver_groups,
        "ticket_data": tickets,
        "asset_data": assets,
        "outage_data": outages,
    }
    for key, required in required_columns.items():
        if not loaded_sets[key]:
            st.error(f"{key.replace('_', ' ').title()} must contain at least one data row.")
            st.stop()
        if not required.issubset(loaded_sets[key][0]):
            st.error(f"Invalid {key.replace('_', ' ')}: required CSV columns are {', '.join(sorted(required))}.")
            st.stop()
    for mapping in resolver_groups:
        if not mapping.get("category", "").strip() or not mapping.get("resolver_group", "").strip():
            st.error("Each resolver mapping must include a category and resolver_group.")
            st.stop()

    if asset_to_apply:
        device_name = asset_to_apply.get("device", "")
        supported_devices = {
            "laptop": "Laptop",
            "desktop": "Desktop",
            "mobile": "Mobile phone",
            "mobile phone": "Mobile phone",
            "phone": "Mobile phone",
            "tablet": "Tablet",
            "printer": "Printer",
        }
        guided_device = supported_devices.get(device_name.casefold(), "Other")
        st.session_state["guided_device"] = guided_device
        if guided_device == "Other":
            st.session_state["guided_other_device"] = device_name
        st.session_state["guided_application"] = asset_to_apply.get("application", "")
        st.session_state["guided_location"] = asset_to_apply.get("location", "")
        st.session_state["guided_asset_id"] = asset_to_apply.get("asset_id", "")
        st.session_state.intake["asset_id"] = asset_to_apply.get("asset_id", "")
        st.toast("Asset details copied into guided intake. Review the values before submitting.")

    with st.sidebar.expander("Active data and CSV templates"):
        st.caption(
            f"Currently loaded: {len(categories)} categories · {len(resolver_groups)} resolver mappings · "
            f"{len(tickets)} tickets · {len(assets)} assets · {len(outages)} outages · "
            f"{sum(article.get('approved') in {'yes', 'true', 'approved'} for article in articles)} approved articles."
        )
        st.caption("Download header-only CSV files to prepare correctly formatted uploads.")
        for filename, label in (
            ("service_categories.csv", "Service categories template"),
            ("resolver_groups.csv", "Resolver mappings template"),
            ("ticket_examples.csv", "Ticket examples template"),
            ("assets.csv", "Assets template"),
            ("known_outages.csv", "Known outages template"),
        ):
            st.download_button(
                label,
                data=csv_template_bytes(DATA_DIR / filename),
                file_name=f"template_{filename}",
                mime="text/csv",
                key=f"template_{filename}",
            )

    with st.sidebar.expander("Quick tools", expanded=True):
        st.markdown("#### Search approved guidance")
        st.caption("Enter symptoms or an error to find approved article titles and source IDs.")
        article_query = st.text_input("Describe a symptom", key="quick_article_query")
        if article_query:
            quick_results = retrieve_articles(article_query, articles, st.session_state.feedback, limit=3)
            if quick_results:
                for result in quick_results:
                    st.write(f"**{result['title']}** · `{result['id']}` · {result['source']}")
            else:
                st.caption("No approved article matched that search.")

        st.markdown("#### Priority preview")
        st.caption("Preview a priority from the configured matrix; this does not create or change a ticket.")
        impact_choice = st.selectbox("Impact", ["High", "Medium", "Low"], index=1, key="quick_impact")
        urgency_choice = st.selectbox("Urgency", ["High", "Medium", "Low"], index=1, key="quick_urgency")
        quick_priority, quick_reason = calculate_priority(impact_choice, urgency_choice, priority_rules)
        st.metric("Suggested priority", quick_priority)
        st.caption(quick_reason)

        st.markdown("#### Duplicate / outage check")
        st.caption("Compare an issue summary to recent tickets and known outages.")
        duplicate_query = st.text_input("Search recent issue summaries", key="quick_duplicate_query")
        if duplicate_query:
            quick_duplicates = find_duplicates(duplicate_query, tickets, outages)
            if quick_duplicates:
                for duplicate in quick_duplicates:
                    st.write(
                        f"**{duplicate['id']}** · {duplicate['summary']} "
                        f"({duplicate['similarity']:.0%} match)"
                    )
            else:
                st.caption("No recent similar ticket or known outage found.")

    issue_templates = {
        "VPN disconnects": (
            "Incident",
            "Network & VPN",
            "My VPN keeps disconnecting and I cannot reliably access internal resources.",
        ),
        "Outlook / email issue": (
            "Incident",
            "Email & Collaboration",
            "Outlook is not connecting or synchronizing my mailbox.",
        ),
        "Teams meeting or audio issue": (
            "Incident",
            "Email & Collaboration",
            "Microsoft Teams meetings have an audio or connection problem.",
        ),
        "Password, sign-in, or MFA": (
            "Incident",
            "Identity & Access",
            "I cannot sign in to my work account or complete MFA.",
        ),
        "Laptop or device problem": (
            "Incident",
            "Endpoint & Hardware",
            "My work laptop or device is not working as expected.",
        ),
        "Printer or peripheral problem": (
            "Incident",
            "Endpoint & Hardware",
            "I cannot use my assigned printer or peripheral device.",
        ),
        "Business application problem": (
            "Incident",
            "Business Applications",
            "A business application is unavailable, slow, or showing an error.",
        ),
        "Report suspected phishing": (
            "Security Incident",
            "Security & Phishing",
            "I received a suspicious message that may be phishing.",
        ),
        "Request new software or equipment": (
            "Service Request",
            "Endpoint & Hardware",
            "I would like to request approved software or equipment.",
        ),
        "Report a wider service outage": (
            "Problem / Outage",
            "Other / Unclassified",
            "A service outage is affecting multiple users or teams.",
        ),
        "Write my own issue": ("Incident", "", ""),
    }
    with st.expander("Guided intake — choose an issue starter or enter details", expanded=not st.session_state.messages):
        st.caption(
            "Select a starter to prefill a description, then correct it for your situation. "
            "The issue description and two ticket tags are used for classification and routing."
        )
        starter = st.selectbox(
            "Common issue starter",
            list(issue_templates),
            help="Selecting a starter fills in a draft summary and suggested ticket tags; all are editable.",
            key="guided_starter",
        )
        default_type, default_category, default_description = issue_templates[starter]
        category_options = [item["category"] for item in categories] + ["Other / Unclassified"]
        if st.session_state.get("_last_guided_starter") != starter:
            st.session_state["guided_ticket_type"] = default_type
            if default_category in category_options:
                st.session_state["guided_category"] = default_category
            st.session_state["guided_description"] = default_description
            st.session_state["_last_guided_starter"] = starter
        selected_type = st.selectbox(
            "Ticket type tag",
            TICKET_TYPES,
            help="Classifies the work: incident, service request, access request, security incident, or wider problem/outage.",
            key="guided_ticket_type",
        )
        selected_category = st.selectbox(
            "Affected service tag",
            category_options,
            help="Choose the service area. This category selects the suggested resolver group.",
            key="guided_category",
        )
        issue_description = st.text_area(
            "What happened?",
            placeholder="Describe the symptoms, when they started, and any error message.",
            help="Use a short factual description. Avoid passwords, MFA codes, or other secrets.",
            key="guided_description",
        )
        device_choice = st.selectbox(
            "Device",
            ["Not sure", "Laptop", "Desktop", "Mobile phone", "Tablet", "Printer", "Other"],
            help="Identify the affected endpoint. Use Asset lookup to prefill this from the asset register.",
            key="guided_device",
        )
        other_device = ""
        if device_choice == "Other":
            other_device = st.text_input("Device type", key="guided_other_device")
        asset_id_for_ticket = st.text_input(
            "Asset ID (optional)",
            placeholder="AST-1001",
            help="Links the incident to an asset record when the ID matches the loaded asset CSV.",
            key="guided_asset_id",
        )
        app_location_col, location_col = st.columns(2)
        with app_location_col:
            application = st.text_input(
                "Application or service (optional)",
                help="Name the app, system, or service involved.",
                key="guided_application",
            )
        with location_col:
            location = st.text_input(
                "Work location (optional)",
                help="Office, site, floor, or remote location; useful for regional issues.",
                key="guided_location",
            )
        impact_col, urgency_col = st.columns(2)
        with impact_col:
            impact = st.selectbox(
                "Impact",
                ["Not sure", "High", "Medium", "Low"],
                help="How broadly is work affected? This and urgency determine the rule-based priority.",
                key="guided_impact",
            )
        with urgency_col:
            urgency = st.selectbox(
                "Urgency",
                ["Not sure", "High", "Medium", "Low"],
                help="How quickly is action needed? Select Not sure if uncertain; the assistant will ask.",
                key="guided_urgency",
            )
        attempted_fixes = st.text_input(
            "What have you tried?",
            placeholder="For example: restarted Outlook, reconnected VPN, or type None",
            help="Mention steps already attempted so support does not repeat them. If you have not tried anything, enter None.",
            key="guided_fixes",
        )
        submit_guided = st.button(
            "Start guided intake",
            type="primary",
            help="Submits these details to the intake assistant. Missing required details will trigger a follow-up.",
        )
        guided_message = ""
        if submit_guided:
            if not issue_description.strip():
                st.warning("Enter a short issue description or choose a common issue starter first.")
            else:
                details = [
                    f"Ticket type: {selected_type}",
                    f"Category: {selected_category}",
                    f"Issue: {issue_description.strip()}",
                ]
                chosen_device = other_device.strip() if device_choice == "Other" else (
                    "" if device_choice == "Not sure" else device_choice
                )
                if chosen_device:
                    details.append(f"Device: {chosen_device}")
                if asset_id_for_ticket.strip():
                    details.append(f"Asset ID: {asset_id_for_ticket.strip()}")
                if application.strip():
                    details.append(f"Application: {application.strip()}")
                if location.strip():
                    details.append(f"Location: {location.strip()}")
                if impact != "Not sure":
                    details.append(f"Impact: {impact}")
                if urgency != "Not sure":
                    details.append(f"Urgency: {urgency}")
                if attempted_fixes.strip():
                    details.append(f"Tried: {attempted_fixes.strip()}")
                guided_message = "\n".join(details)

    with st.expander("Agent roles and workflow"):
        st.markdown(
            "- **Issue Intake Agent:** extracts incident details, remembers prior answers, and asks only for missing fields.\n"
            "- **Knowledge Retrieval Agent:** searches local articles and cites the source for each approved step.\n"
            "- **Ticket Routing Agent:** detects recent similar tickets/outages, applies the impact/urgency matrix, and explains routing.\n"
            "- **Human review:** review or edit the ticket JSON before recording it as ready for routing."
        )

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    chat_message = st.chat_input("Describe the IT issue, or answer the follow-up question...")
    user_message = guided_message or chat_message
    if user_message and user_message.strip():
        st.session_state.prepared_ticket = None
        st.session_state.messages.append({"role": "user", "content": user_message})
        st.session_state.intake["issue_description"] = (
            f"{st.session_state.intake.get('issue_description', '')}\n{user_message}".strip()
        )
        locally_extracted = extract_local_fields(user_message)
        model_extracted, model_warning = call_intake_llm(user_message, st.session_state.intake, categories)
        updates: dict[str, Any] = {}
        if model_extracted:
            updates = {
                key: value
                for key, value in model_extracted.items()
                if key in {
                    "summary", "category", "ticket_type", "device", "application", "location", "impact",
                    "urgency", "attempted_fixes", "diagnostics", "confidence",
                }
                and value is not None
                and (
                    isinstance(value, (int, float)) and not isinstance(value, bool)
                    if key == "confidence"
                    else isinstance(value, str)
                )
                and str(value).strip().casefold() not in UNKNOWN_VALUES
            }
        updates.update(locally_extracted)
        st.session_state.intake.update(updates)
        for field in ("impact", "urgency"):
            value = str(st.session_state.intake.get(field, "")).strip()
            if value.casefold() not in {"high", "medium", "low"}:
                st.session_state.intake[field] = ""
        st.session_state.intake["asset_id"] = (
            st.session_state.intake.get("asset_id") or asset_id
        )
        if model_warning:
            add_audit_event("llm_fallback", {"reason": model_warning})

        missing = [
            field for field in REQUIRED_INTAKE_FIELDS
            if not st.session_state.intake.get(field)
            and field not in st.session_state.asked_fields
        ]
        if missing:
            st.session_state.asked_fields.update(missing)
            labels = {
                "device": "device or asset",
                "application": "application/service",
                "location": "work location",
                "impact": "impact (how many people or services are affected)",
                "urgency": "urgency (how time-sensitive the issue is)",
                "attempted_fixes": "fixes already attempted (or say none)",
            }
            response_text = "To complete the ticket, please provide: " + "; ".join(labels[field] for field in missing) + "."
        else:
            for field in REQUIRED_INTAKE_FIELDS:
                st.session_state.intake.setdefault(field, "Not provided")
            description = st.session_state.intake["issue_description"]
            category, local_confidence = classify_category(description, categories)
            extracted_category = st.session_state.intake.get("category")
            if isinstance(extracted_category, str) and (
                extracted_category in {item["category"] for item in categories}
                or extracted_category == "Other / Unclassified"
            ):
                category = extracted_category
            try:
                confidence = float(st.session_state.intake.get("confidence", local_confidence))
            except (TypeError, ValueError):
                confidence = local_confidence
            if not 0.0 <= confidence <= 1.0:
                confidence = local_confidence
            priority, priority_reason = calculate_priority(
                st.session_state.intake["impact"],
                st.session_state.intake["urgency"],
                priority_rules,
            )
            resolver, route_reason = group_for_category(category, resolver_groups)
            query = " ".join([
                description,
                str(st.session_state.intake.get("application", "")),
                str(st.session_state.intake.get("device", "")),
                str(st.session_state.intake.get("diagnostics", "")),
            ])
            references = retrieve_articles(query, articles, st.session_state.feedback)
            duplicates = find_duplicates(description, tickets, outages)
            asset_record = find_asset(str(st.session_state.intake.get("asset_id", "")), assets)
            evidence = [
                {
                    "source": item["source"],
                    "article_id": item["id"],
                    "title": item["title"],
                    "relevance": item["score"],
                }
                for item in references
            ]
            for duplicate in duplicates:
                evidence.append({"source": duplicate["type"], **duplicate})

            missing_mappings = category == "Other / Unclassified" or resolver == "Service Desk - Triage"
            needs_review = confidence < 0.65 or bool(duplicates) or missing_mappings
            ticket_type = st.session_state.intake.get("ticket_type")
            if ticket_type not in TICKET_TYPES:
                ticket_type = classify_ticket_type(description)
            st.session_state.prepared_ticket = {
                "ticket_id": f"INC-{uuid4().hex[:12].upper()}",
                "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "ticket_type": ticket_type,
                "category": category,
                "summary": st.session_state.intake.get("summary")
                or description.splitlines()[0][:160],
                "diagnostics": {
                    "device": st.session_state.intake["device"],
                    "asset_id": st.session_state.intake.get("asset_id", ""),
                    "application": st.session_state.intake["application"],
                    "location": st.session_state.intake["location"],
                    "impact": st.session_state.intake["impact"],
                    "urgency": st.session_state.intake["urgency"],
                    "attempted_fixes": st.session_state.intake["attempted_fixes"],
                    "notes": st.session_state.intake.get("diagnostics", ""),
                    "asset_record": asset_record,
                },
                "evidence": evidence,
                "recommended_self_service": [
                    {
                        "article_id": item["id"],
                        "source": item["source"],
                        "title": item["title"],
                        "steps": re.findall(r"(?m)^-\s*(.+)$", item["content"]),
                    }
                    for item in references
                ],
                "priority": {
                    "level": priority,
                    "impact": st.session_state.intake["impact"],
                    "urgency": st.session_state.intake["urgency"],
                    "explanation": priority_reason,
                },
                "suggested_resolver_group": resolver,
                "routing_explanation": route_reason,
                "classification_confidence": confidence,
                "needs_human_review": needs_review,
                "duplicate_matches": duplicates,
            }
            response_text = (
                f"Intake is complete. I found {len(references)} support article(s) and "
                f"{len(duplicates)} recent similar ticket/outage match(es). "
                "Review the prepared ticket and routing explanation below."
            )
            add_audit_event("ticket_prepared", {
                "ticket_id": st.session_state.prepared_ticket["ticket_id"],
                "category": category,
                "priority": priority,
            })
        if model_warning:
            response_text += f"\n\n_{model_warning}_"
        st.session_state.messages.append({"role": "assistant", "content": response_text})
        st.rerun()

    if st.session_state.prepared_ticket:
        ticket = st.session_state.prepared_ticket
        st.subheader("Recommended self-service guidance")
        if ticket["recommended_self_service"]:
            for suggestion in ticket["recommended_self_service"]:
                with st.expander(f"{suggestion['title']} — source: {suggestion['source']}"):
                    article = next(
                        (item for item in articles if item["id"] == suggestion["article_id"]),
                        None,
                    )
                    if article:
                        st.markdown(article["content"])
                    if st.button("This step resolved the issue", key=f"helped_{suggestion['article_id']}"):
                        st.session_state.feedback[suggestion["article_id"]] = (
                            st.session_state.feedback.get(suggestion["article_id"], 0) + 1
                        )
                        add_audit_event("resolution_feedback", {
                            "article_id": suggestion["article_id"],
                            "resolved": True,
                        })
                        st.success("Thanks. Future retrieval in this session will boost this article.")
                    if st.button("This step did not resolve the issue", key=f"not_helped_{suggestion['article_id']}"):
                        st.session_state.feedback[suggestion["article_id"]] = (
                            st.session_state.feedback.get(suggestion["article_id"], 0) - 1
                        )
                        add_audit_event("resolution_feedback", {
                            "article_id": suggestion["article_id"],
                            "resolved": False,
                        })
                        st.info("Thanks. Future retrieval in this session will lower this article's rank.")
        else:
            st.info("No matching approved support article was found. No self-service steps are being recommended.")

        st.subheader("Duplicate detection and routing explanation")
        if ticket["duplicate_matches"]:
            st.warning("Potential duplicate or known outage found. Review before creating a new incident.")
            st.dataframe(ticket["duplicate_matches"], width="stretch", hide_index=True)
        else:
            st.success("No recent ticket or known outage met the similarity threshold.")
        st.write(f"**Priority:** {ticket['priority']['level']} — {ticket['priority']['explanation']}")
        st.write(
            f"**Resolver group:** {ticket['suggested_resolver_group']} — "
            f"{ticket['routing_explanation']}"
        )
        st.write(
            f"**Classification confidence:** {ticket['classification_confidence']:.0%} "
            f"({'human review recommended' if ticket['needs_human_review'] else 'standard review'})"
        )

        st.subheader("Review and prepare ticket")
        st.caption(
            "Edit the JSON if needed. The ticket is only recorded in this session after you confirm review; "
            "download the JSON to pass it to your ticketing workflow."
        )
        st.markdown(f"**Ticket tags:** `{ticket['ticket_type']}` · `{ticket['category']}`")
        edited_json = st.text_area(
            "Ticket JSON (editable)",
            value=json.dumps(ticket, indent=2, ensure_ascii=False),
            height=420,
            key="ticket_editor",
        )
        try:
            reviewed_ticket = json.loads(edited_json)
            validate_ticket(reviewed_ticket)
            ticket_valid = True
        except (json.JSONDecodeError, ValueError) as error:
            ticket_valid = False
            st.error(f"Ticket JSON is invalid: {error}")
            reviewed_ticket = {}
        reviewed = st.checkbox("I reviewed this ticket and its routing recommendation.")
        if st.button("Mark ticket ready for routing", disabled=not ticket_valid or not reviewed):
            add_audit_event("ticket_ready_for_routing", reviewed_ticket)
            st.success("Ticket validated and recorded in this session's audit log. No external ticket system was contacted.")
        st.download_button(
            "Download ticket JSON",
            data=json.dumps(reviewed_ticket if ticket_valid else ticket, indent=2, ensure_ascii=False),
            file_name=f"{ticket['ticket_id']}.json",
            mime="application/json",
        )

        st.subheader("Session memory")
        st.json({
            "device": st.session_state.intake.get("device"),
            "application": st.session_state.intake.get("application"),
            "location": st.session_state.intake.get("location"),
            "attempted_fixes": st.session_state.intake.get("attempted_fixes"),
        })

    with st.expander("Audit log"):
        st.json(st.session_state.audit_log)
        if st.session_state.audit_log:
            st.download_button(
                "Download session audit log",
                data=json.dumps(st.session_state.audit_log, indent=2, ensure_ascii=False),
                file_name="helpdesk_audit_log.json",
                mime="application/json",
            )


if __name__ == "__main__":
    main()
