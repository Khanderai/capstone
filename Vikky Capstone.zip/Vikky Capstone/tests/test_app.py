import json
import unittest

import app


class HelpdeskLogicTests(unittest.TestCase):
    def test_priority_uses_uploaded_impact_urgency_matrix(self):
        rules = [
            {"impact": "High", "urgency": "High", "priority": "P1"},
            {"impact": "Medium", "urgency": "Medium", "priority": "P3"},
        ]
        self.assertEqual(app.calculate_priority("High", "High", rules)[0], "P1")
        priority, reason = app.calculate_priority("Not provided", "Medium", rules)
        self.assertEqual(priority, "P3")
        self.assertIn("treated as Medium", reason)

    def test_local_article_retrieval_returns_cited_source(self):
        articles = [
            {"id": "KB-VPN", "title": "VPN disconnects", "content": "Reconnect approved VPN.", "source": "kb.txt", "approved": "yes"},
            {"id": "KB-MAIL", "title": "Mailbox sync", "content": "Restart Outlook.", "source": "mail.txt", "approved": "yes"},
            {"id": "KB-UNAPPROVED", "title": "VPN fix", "content": "Disable security controls.", "source": "unsafe.txt", "approved": "no"},
        ]
        matches = app.retrieve_articles("VPN disconnects", articles)
        self.assertEqual(matches[0]["id"], "KB-VPN")
        self.assertEqual(matches[0]["source"], "kb.txt")
        self.assertNotIn("KB-UNAPPROVED", [article["id"] for article in matches])

    def test_uploaded_priority_rules_must_cover_complete_matrix(self):
        rules = json.loads((app.DATA_DIR / "priority_rules.json").read_text(encoding="utf-8"))
        app.validate_priority_rules(rules)
        with self.assertRaises(ValueError):
            app.validate_priority_rules(rules[:-1])

    def test_csv_template_contains_source_headers_without_sample_rows(self):
        template = app.csv_template_bytes(app.DATA_DIR / "assets.csv").decode("utf-8")
        self.assertEqual(
            template.strip(),
            "asset_id,device,serial_number,assigned_to,location,operating_system,application",
        )

    def test_unapproved_uploaded_article_is_not_retrieved(self):
        articles = app.parse_articles(
            "ID: KB-DRAFT\nTitle: VPN workaround\nApproved: no\nSteps:\n- Disable security controls.",
            "draft.txt",
        )
        self.assertEqual(app.retrieve_articles("VPN workaround", articles), [])

    def test_local_intake_extracts_fields_without_reasking_data(self):
        fields = app.extract_local_fields(
            "Category: Network & VPN\nDevice: MacBook Pro, application: GlobalProtect VPN, "
            "location: Mumbai, urgency: High, Tried: reconnecting."
        )
        self.assertEqual(fields["device"], "MacBook Pro")
        self.assertEqual(fields["category"], "Network & VPN")
        self.assertEqual(fields["application"], "GlobalProtect VPN")
        self.assertEqual(fields["location"], "Mumbai")
        self.assertEqual(fields["urgency"], "High")
        self.assertEqual(fields["attempted_fixes"], "reconnecting")

    def test_category_classification_and_resolver_routing(self):
        categories = app.read_csv_file(app.DATA_DIR / "service_categories.csv")
        category, confidence = app.classify_category("GlobalProtect VPN keeps disconnecting", categories)
        self.assertEqual(category, "Network & VPN")
        self.assertGreater(confidence, 0.5)
        group, reason = app.group_for_category(
            category,
            app.read_csv_file(app.DATA_DIR / "resolver_groups.csv"),
        )
        self.assertEqual(group, "Network Operations")
        self.assertTrue(reason)

    def test_ticket_type_classification_offers_expected_dropdown_values(self):
        self.assertEqual(app.classify_ticket_type("I received a suspicious phishing email"), "Security Incident")
        self.assertEqual(app.classify_ticket_type("Please request access to the reporting portal"), "Access Request")
        self.assertEqual(app.classify_ticket_type("A service outage affects multiple teams"), "Problem / Outage")
        self.assertEqual(app.classify_ticket_type("VPN keeps disconnecting"), "Incident")
        self.assertEqual(app.classify_ticket_type("I cannot sign in to my account"), "Incident")
        fields = app.extract_local_fields(
            "Ticket type: Service Request\nCategory: Endpoint & Hardware\nIssue: Request a new laptop"
        )
        self.assertEqual(fields["ticket_type"], "Service Request")
        self.assertEqual(fields["category"], "Endpoint & Hardware")

    def test_asset_lookup_matches_id_case_insensitively(self):
        assets = [{"asset_id": "AST-1001", "device": "Laptop"}]
        self.assertEqual(app.find_asset("ast-1001", assets), assets[0])
        self.assertIsNone(app.find_asset("unknown", assets))

    def test_duplicate_detection_finds_recent_similar_ticket(self):
        tickets = [{
            "ticket_id": "INC-1",
            "created_at": "2099-01-01",
            "summary": "VPN connection keeps disconnecting",
            "description": "GlobalProtect VPN drops after sign-in",
            "status": "Open",
        }]
        matches = app.find_duplicates("GlobalProtect VPN keeps dropping after sign-in", tickets, [])
        self.assertTrue(matches)
        self.assertEqual(matches[0]["id"], "INC-1")

    def test_ticket_requires_structured_diagnostics_and_evidence(self):
        ticket = {
            "ticket_id": "INC-1",
            "ticket_type": "Incident",
            "category": "Network & VPN",
            "summary": "VPN issue",
            "diagnostics": {},
            "evidence": [],
            "priority": {
                "level": "P2",
                "impact": "High",
                "urgency": "Medium",
                "explanation": "Impact and urgency rule.",
            },
            "suggested_resolver_group": "Network Operations",
        }
        app.validate_ticket(ticket)
        ticket["diagnostics"] = []
        with self.assertRaises(ValueError):
            app.validate_ticket(ticket)
        with self.assertRaises(ValueError):
            app.validate_ticket([])
        ticket["diagnostics"] = {}
        ticket["ticket_type"] = "Unknown"
        with self.assertRaises(ValueError):
            app.validate_ticket(ticket)


if __name__ == "__main__":
    unittest.main()
